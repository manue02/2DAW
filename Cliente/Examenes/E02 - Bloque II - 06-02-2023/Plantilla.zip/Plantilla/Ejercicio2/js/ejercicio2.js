document.getElementById("botonRestaurar").addEventListener("click", () => location.reload());

document.getElementById("botonEjecutar").addEventListener("click", Ejecutar);
