<?php 
header ("Location:pag1.php");
?>