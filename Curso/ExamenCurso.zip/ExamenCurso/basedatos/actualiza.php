<html>
<head>
<title> Gestión de aulas </title>
</head>
<body>
<h1>Gestión de aulas</h1>
<p>
<?php
echo 'Se ha actualizado la fila'; 
echo "<p><a href='selecciondepartamento.php'>Página Inicial</a></p>";
?>