<?php
$futbolista['david'] = array("apellidos" => "lopez","posicion" => "defensa","edad" => 25,"equipo"=>"Betis");
$futbolista['luis'] = array("apellidos" => "perez","posicion" => "portero","edad" => 22,"estado"=>"transfer");
$futbolista['carlos'] = array("apellidos" => "dominguez","posicion" => "defensa","edad" => 26,"equipo"=>"Recre");
$futbolista['andres'] = array("apellidos" => "juarez","posicion" => "portero","edad" => 27);
$futbolista['jose'] = array("apellidos" => "marquez","posicion" => "defensa","edad" => 29);
$futbolista['miguel'] = array("apellidos" => "romero","posicion" => "delantero","edad" => 31,"equipo"=>"Cádiz");
$futbolista['manuel'] = array("apellidos" => "lozano","posicion" => "medio","edad" => 36,"estado"=>"lesionado");
$futbolista['diego'] = array("apellidos" => "rodriguez","posicion" => "delantero","edad" => 37,"estado"=>"lesionado");
?>