<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "
http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Ejercicio 1</title>
</head>
<body>
<h2>No hay artículos de la selección efectuada:</h2>
<table border="1"><Tr><th>Linea</th></tr><tr><td>
</td></tr></table></div>
</body>
</html>