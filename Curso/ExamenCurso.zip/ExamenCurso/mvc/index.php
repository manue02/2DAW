<?php
header("Location: Controller/parte1.php");
?>