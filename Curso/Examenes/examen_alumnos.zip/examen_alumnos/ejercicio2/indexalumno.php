﻿<?php 
	
	
			include('funciones2.php');
			cabecera('Instituto');
			
?>
