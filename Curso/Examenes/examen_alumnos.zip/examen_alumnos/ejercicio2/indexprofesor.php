﻿<?php 

			
			include('funciones1.php');
			cabecera('Instituto');
			
			
	
?>
