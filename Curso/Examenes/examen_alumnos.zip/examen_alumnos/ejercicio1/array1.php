<?php
$datos = array
(
    "Luis" => array("sexo" => "Masculino", "edad" => 32, "idiomas" => array("Castellano", "Aleman")),
    "Pierre" => array("sexo" => "Masculino", "edad" => 33, "idiomas" => array("Frances", "Ingles", "Chino", "Japones")),
    "Maria" => array("sexo" => "Femenino", "edad" => 29, "idiomas" => array("Castellano", "Ingles")),
    "Julian" => array("sexo" => "Masculino", "edad" => 27, "idiomas" => array("Castellano", "Ingles", "Aleman")),
    "Pedro" => array("sexo" => "Masculino", "edad" => 31, "idiomas" => array("Castellano", "Frances", "Chino")),
    "Linda" => array("sexo" => "Femenino", "edad" => 26, "idiomas" => array("Frances", "Ingles", "Aleman")),
    "Steffi" => array("sexo" => "Femenino", "edad" => 28, "idiomas" => array("Aleman", "Ingles", "Sueco")),
    "Julian" => array("sexo" => "Masculino", "edad" => 35, "idiomas" => array("Castellano", "Ingles", "Frances"))

);



echo "<pre>";
print_r($datos);
echo "</pre>";
?>