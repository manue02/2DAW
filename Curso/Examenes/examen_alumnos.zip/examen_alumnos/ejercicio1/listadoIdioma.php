<?php
include("array1.php");



//obtener un listado ordenado de todos los idiomas





?>