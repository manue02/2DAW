<?php
include("array1.php");

echo "<form action='VerDatos.php' method='POST'>
	  <select name='Datos'>";


//mostrar un combo para que muestre los nombres ordenados alfabeticamente y mostrar los datos de la persona elegida






echo "</select> <br>";

echo "
    <input type='submit' value='Ver Idiomas'>
    </form>";





?>