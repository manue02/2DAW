<?php
  setcookie("noticias","",time()-100);
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Problema</title>
</head>
<body>
<h2>Se borró correctamente</h2>
<a href="ejercicio4_cookies.php">Ir a la otra página</a>
</body>
</html>