<?php
setcookie("usuario","diego",0);
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Problema</title>
</head>
<body>
Cookie de sesión creada.<br>
<a href="ejercicio5_cookies.php">Retornar a la página anterior.</a>
</body>
</html>