<?php
include('funciones.php');
cabecera('Consultas Preparadas');
echo "<h1>CONTROL DE ASISTENCIA EN D.A.W.</h1>";
echo "<img src='tablas.jpg'>"; 
		echo "</div>";
		pie();
?>
